# ADB Maintenance Toolkit

A lightweight, dependency-free (standard library only) CLI for common Android
maintenance tasks over ADB. Works on Linux (Ubuntu) and Android Termux.
Windows support is prepared (no shell tricks, `shutil.which`, `.exe` paths).

## Requirements
- Python 3.7+
- ADB (Ubuntu: `sudo apt install adb` | Termux: `pkg install android-tools`)
- USB debugging enabled on the phone

## Run
    cd adb-maintenance-toolkit
    python3 -m adbtk                 # serial numbers hidden
    python3 -m adbtk --show-serial   # show full serials

## Try without a phone
    chmod +x tests/fake_adb.py
    ADBTK_ADB=$PWD/tests/fake_adb.py python3 -m adbtk

## Run tests
    python3 -m unittest discover -s tests -v

## Safety
- `rm -rf /`, `rm -rf /data/*`, `pm clear` (including `--all`) are blocked in `core/safety.py`.
- Only one delete form is allowed: `rm -f -- '<single temp file>'`, never inside `/sdcard/Android`.
- Temp cleanup lists files first; you choose; you must type `yes`.
- Cache maintenance uses Android's own `pm trim-caches`.
- Serial numbers are masked unless `--show-serial` is used.
