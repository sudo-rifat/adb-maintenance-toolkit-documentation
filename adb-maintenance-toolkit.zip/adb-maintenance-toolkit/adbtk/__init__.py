"""ADB Maintenance Toolkit - a lightweight, dependency-free ADB helper."""
__version__ = "1.0.0"
