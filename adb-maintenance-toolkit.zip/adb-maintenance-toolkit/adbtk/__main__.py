"""Entry point:  python3 -m adbtk"""
import argparse
import sys

from . import __version__
from .core import adb, device
from .ui import menu, prompts
from .utils import platform_utils


def main(argv=None):
    parser = argparse.ArgumentParser(prog="adbtk", description="ADB Maintenance Toolkit")
    parser.add_argument("--show-serial", action="store_true",
                        help="show full device serial numbers (hidden by default)")
    parser.add_argument("--version", action="version", version="adbtk " + __version__)
    args = parser.parse_args(argv)

    if sys.version_info < (3, 7):
        print("Python 3.7 or newer is required.")
        return 1

    print("Platform: %s" % platform_utils.detect_platform())
    if not adb.find_adb():
        prompts.error("ADB was not found on this system.\n")
        print(platform_utils.adb_install_help())
        return 1

    session = device.Session(show_serial=args.show_serial)
    try:
        menu.run(session)
    except (KeyboardInterrupt, EOFError):
        print("\nGoodbye!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
