"""Finds ADB and runs commands. The ONLY file that starts ADB processes."""
import os
import shutil
import subprocess
from collections import namedtuple

from . import safety
from ..utils import platform_utils

Result = namedtuple("Result", "ok out err code")


class AdbError(Exception):
    pass


def find_adb():
    """Return the path to adb, or None. Env var ADBTK_ADB overrides."""
    custom = os.environ.get("ADBTK_ADB")
    if custom and os.path.isfile(custom):
        return custom
    path = shutil.which("adb")
    if path:
        return path
    for p in platform_utils.common_adb_paths():
        if os.path.isfile(p) and os.access(p, os.X_OK):
            return p
    return None


def adb_version():
    try:
        r = run(["version"], timeout=10)
        return r.out.splitlines()[0] if r.out else "unknown"
    except AdbError:
        return "unknown"


def run(args, serial=None, timeout=30):
    """Run an adb command (args is a list). Safety-checked for `shell`."""
    adb = find_adb()
    if not adb:
        raise AdbError("ADB not found.")
    if args and args[0] == "shell":
        safety.check_shell_command(" ".join(args[1:]))
    cmd = [adb]
    if serial:
        cmd += ["-s", serial]
    cmd += list(args)
    try:
        p = subprocess.run(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            universal_newlines=True, errors="replace", timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        raise AdbError("Command timed out after %d seconds." % timeout)
    except OSError as e:
        raise AdbError("Could not run ADB: %s" % e)
    return Result(p.returncode == 0, p.stdout, p.stderr, p.returncode)


def shell(serial, command, timeout=30):
    return run(["shell", command], serial=serial, timeout=timeout)
