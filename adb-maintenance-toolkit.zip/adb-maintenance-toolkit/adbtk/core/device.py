"""Device discovery, selection and connection checks."""
import re

from . import adb
from ..ui import prompts
from ..utils.formatting import mask_serial
from ..utils.platform_utils import adb_install_help  # noqa: F401  (re-exported)


class Session:
    """Holds the currently selected device."""

    def __init__(self, show_serial=False):
        self.serial = None
        self.model = ""
        self.show_serial = show_serial

    def shown_serial(self, serial=None):
        s = serial or self.serial
        return s if self.show_serial else mask_serial(s)

    def label(self):
        if not self.serial:
            return "No device selected"
        return "%s (%s)" % (self.model or "Android", self.shown_serial())


def list_devices():
    r = adb.run(["devices", "-l"])
    devices = []
    for line in r.out.splitlines()[1:]:
        line = line.strip()
        if not line or line.startswith("*"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        d = {"serial": parts[0], "state": parts[1], "model": ""}
        for p in parts[2:]:
            if p.startswith("model:"):
                d["model"] = p[6:].replace("_", " ")
        devices.append(d)
    return devices


def select_device(session):
    """List devices and let the user pick one. Returns True if selected."""
    devices = list_devices()
    if not devices:
        prompts.warn("No Android device found.")
        print("  - Connect the phone with a USB cable")
        print("  - Enable Developer options > USB debugging")
        print("  - Or use wireless connect from this menu (Device Connection)")
        return False

    prompts.title("Connected devices")
    for i, d in enumerate(devices, 1):
        print("  %d) %-22s %-13s %s" % (i, session.shown_serial(d["serial"]), d["state"], d["model"]))

    ready = [d for d in devices if d["state"] == "device"]
    if not ready:
        prompts.warn("No device is ready.")
        print("  'unauthorized' = accept the 'Allow USB debugging?' popup on the phone.")
        print("  'offline'      = unplug/replug or run: adb kill-server")
        return False

    if len(ready) == 1:
        chosen = ready[0]
        prompts.ok("Auto-selected the only ready device.")
    else:
        chosen = None
        while chosen is None:
            ans = prompts.ask("Select device number (or Enter to cancel): ").strip()
            if not ans:
                return False
            if ans.isdigit() and 1 <= int(ans) <= len(devices) and devices[int(ans) - 1]["state"] == "device":
                chosen = devices[int(ans) - 1]
            else:
                prompts.warn("Invalid choice. Pick a device whose state is 'device'.")

    session.serial = chosen["serial"]
    session.model = chosen["model"]
    return True


def is_connected(session):
    if not session.serial:
        return False
    try:
        r = adb.run(["get-state"], serial=session.serial, timeout=10)
    except adb.AdbError:
        return False
    return r.ok and r.out.strip() == "device"


def ensure_connected(session):
    """Run before every device command. Returns True when a device is ready."""
    if is_connected(session):
        return True
    if session.serial:
        prompts.warn("Device %s is not reachable anymore." % session.shown_serial())
        session.serial = None
    return select_device(session)


_HOSTPORT = re.compile(r"^[A-Za-z0-9_.\-]+:\d{1,5}$")


def connection_menu(session):
    while True:
        prompts.title("Device Connection")
        print("  Current: %s" % session.label())
        print("  1) List / select device")
        print("  2) Wireless connect (IP:PORT)")
        print("  3) Wireless pair (IP:PORT + pairing code)")
        print("  0) Back")
        choice = prompts.ask("Choice: ").strip()
        if choice == "1":
            select_device(session)
        elif choice == "2":
            hp = prompts.ask("Enter IP:PORT (e.g. 192.168.0.5:5555): ").strip()
            if not _HOSTPORT.match(hp):
                prompts.warn("Invalid format. Use IP:PORT.")
                continue
            r = adb.run(["connect", hp], timeout=20)
            print((r.out or r.err).strip())
            select_device(session)
        elif choice == "3":
            hp = prompts.ask("Pairing IP:PORT (from the phone's pairing dialog): ").strip()
            code = prompts.ask("6-digit pairing code: ").strip()
            if not _HOSTPORT.match(hp) or not code.isdigit():
                prompts.warn("Invalid IP:PORT or code.")
                continue
            r = adb.run(["pair", hp, code], timeout=30)
            print((r.out or r.err).strip())
            prompts.info("Now use option 2 with the *connect* IP:PORT shown on the Wireless debugging screen.")
        elif choice == "0":
            return
        else:
            prompts.warn("Invalid choice.")
