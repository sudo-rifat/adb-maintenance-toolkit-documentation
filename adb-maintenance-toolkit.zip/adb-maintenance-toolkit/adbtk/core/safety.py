"""Safety rules. Every `adb shell` command is checked here before it runs."""
import re
import shlex


class SafetyError(Exception):
    """Raised when a command is blocked for safety reasons."""


ALLOWED_DELETE_PREFIXES = ("/sdcard/", "/storage/emulated/0/", "/data/local/tmp/")
PROTECTED_PREFIXES = ("/sdcard/Android/", "/storage/emulated/0/Android/")

BLOCKED_PATTERNS = [
    (r"\bpm\s+clear\b", "'pm clear' can erase app data and is blocked."),
    (r"\bpm\s+uninstall\b", "This tool never uninstalls apps."),
    (r"\b(mkfs|mke2fs|wipe|fastboot|dd)\b", "Disk-level commands are blocked."),
    (r"\bformat\b", "Format commands are blocked."),
    (r"\bsu\b", "Root commands are blocked."),
    (r">\s*/dev/(?!null\b)", "Writing to device nodes is blocked."),
    (r"/data/\*", "Wildcards on /data are blocked."),
]


def is_safe_temp_path(path):
    """True only for a single file path that this tool is allowed to delete."""
    if not path or "\n" in path or path.endswith("/"):
        return False
    if ".." in path.split("/"):
        return False
    if "*" in path or "?" in path:
        return False
    if not path.startswith(ALLOWED_DELETE_PREFIXES):
        return False
    if path.startswith(PROTECTED_PREFIXES):
        return False
    return True


def check_shell_command(command):
    """Raise SafetyError if the command is not allowed."""
    # The ONLY allowed delete form: rm -f -- '<one safe file>'
    if re.search(r"(^|[\s;&|(])rm(\s|$)", command):
        try:
            tokens = shlex.split(command)
        except ValueError:
            raise SafetyError("Could not understand the delete command; blocked.")
        if (
            len(tokens) == 4
            and tokens[:3] == ["rm", "-f", "--"]
            and command == "rm -f -- " + shlex.quote(tokens[3])
            and is_safe_temp_path(tokens[3])
        ):
            return
        raise SafetyError("Only single, safe temporary files can be deleted. Command blocked.")

    for pattern, message in BLOCKED_PATTERNS:
        if re.search(pattern, command):
            raise SafetyError(message)
