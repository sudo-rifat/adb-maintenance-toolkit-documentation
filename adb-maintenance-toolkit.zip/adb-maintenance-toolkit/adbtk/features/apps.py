"""Installed / third-party / system app lists (read-only)."""
from ..core import adb
from ..ui import prompts

PAGE = 40


def _list(session, flag, title):
    prompts.title(title)
    r = adb.shell(session.serial, "pm list packages %s" % flag, timeout=60)
    pkgs = sorted(l.strip()[8:] for l in r.out.splitlines() if l.strip().startswith("package:"))
    if not r.ok or not pkgs:
        prompts.error("Could not read the package list.")
        return
    print("  Total: %d apps" % len(pkgs))
    kw = prompts.ask("Filter by keyword (Enter = show all): ").strip().lower()
    if kw:
        pkgs = [p for p in pkgs if kw in p.lower()]
        print("  Matches: %d" % len(pkgs))
    for i, p in enumerate(pkgs, 1):
        print("  %3d. %s" % (i, p))
        if i % PAGE == 0 and i < len(pkgs):
            if prompts.ask("  -- Enter = more, q = stop: ").strip().lower() == "q":
                break


def show_installed(session):
    _list(session, "", "Installed Apps")


def show_third_party(session):
    _list(session, "-3", "Third-party Apps")


def show_system(session):
    _list(session, "-s", "System Apps")
