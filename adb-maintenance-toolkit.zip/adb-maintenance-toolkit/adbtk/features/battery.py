"""Battery information and statistics."""
import re

from ..core import adb
from ..ui import prompts

STATUS = {"1": "Unknown", "2": "Charging", "3": "Discharging", "4": "Not charging", "5": "Full"}
HEALTH = {"1": "Unknown", "2": "Good", "3": "Overheat", "4": "Dead",
          "5": "Over voltage", "6": "Failure", "7": "Cold"}


def _parse_kv(text):
    data = {}
    for line in text.splitlines():
        m = re.match(r"^\s*([A-Za-z][\w .]*?):\s*(.*)$", line)
        if m:
            data[m.group(1).strip().lower()] = m.group(2).strip()
    return data


def show_battery_info(session):
    prompts.title("Battery Information")
    r = adb.shell(session.serial, "dumpsys battery")
    if not r.ok or not r.out.strip():
        prompts.error("Could not read battery information.")
        return
    d = _parse_kv(r.out)
    level, scale = d.get("level", "?"), d.get("scale", "100")
    plugged = []
    if d.get("ac powered") == "true":
        plugged.append("AC")
    if d.get("usb powered") == "true":
        plugged.append("USB")
    if d.get("wireless powered") == "true":
        plugged.append("Wireless")
    try:
        temp = "%.1f C" % (int(d["temperature"]) / 10.0)
    except (KeyError, ValueError):
        temp = "N/A"
    try:
        volt = "%.2f V" % (int(d["voltage"]) / 1000.0)
    except (KeyError, ValueError):
        volt = "N/A"
    prompts.table([
        ("Level", "%s / %s" % (level, scale)),
        ("Status", STATUS.get(d.get("status", ""), d.get("status", "N/A"))),
        ("Health", HEALTH.get(d.get("health", ""), d.get("health", "N/A"))),
        ("Power source", ", ".join(plugged) or "Battery"),
        ("Temperature", temp),
        ("Voltage", volt),
        ("Technology", d.get("technology", "N/A")),
    ])


KEYWORDS = ("time on battery", "estimated battery capacity", "last learned battery capacity",
            "min learned battery capacity", "max learned battery capacity", "screen on",
            "screen off", "computed drain", "actual drain", "discharge", "charge counter")


def show_battery_stats(session):
    prompts.title("Battery Statistics")
    r = adb.shell(session.serial, "dumpsys batterystats", timeout=90)
    if not r.ok or not r.out.strip():
        prompts.error("Could not read battery statistics.")
        return
    lines, seen = [], set()
    for line in r.out.splitlines():
        low = line.strip().lower()
        if any(k in low for k in KEYWORDS) and low not in seen:
            seen.add(low)
            lines.append(line.strip())
        if len(lines) >= 25:
            break
    if not lines:
        prompts.warn("No summary statistics available on this device.")
        return
    for line in lines:
        print("  " + line)
