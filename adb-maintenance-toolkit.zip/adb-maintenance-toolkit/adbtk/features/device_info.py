"""Android version, model, manufacturer."""
from ..core import adb
from ..ui import prompts


def _prop(session, key):
    r = adb.shell(session.serial, "getprop %s" % key)
    v = r.out.strip()
    return v if r.ok and v else "N/A"


def show_android_version(session):
    prompts.title("Android Version")
    prompts.table([
        ("Android version", _prop(session, "ro.build.version.release")),
        ("API level (SDK)", _prop(session, "ro.build.version.sdk")),
        ("Security patch", _prop(session, "ro.build.version.security_patch")),
        ("Build ID", _prop(session, "ro.build.id")),
    ])


def show_model(session):
    prompts.title("Device Model")
    prompts.table([
        ("Model", _prop(session, "ro.product.model")),
        ("Device codename", _prop(session, "ro.product.device")),
        ("Product name", _prop(session, "ro.product.name")),
    ])


def show_manufacturer(session):
    prompts.title("Manufacturer")
    prompts.table([
        ("Manufacturer", _prop(session, "ro.product.manufacturer")),
        ("Brand", _prop(session, "ro.product.brand")),
        ("Hardware", _prop(session, "ro.hardware")),
    ])
