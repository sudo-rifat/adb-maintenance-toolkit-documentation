"""Cache trimming and temporary file cleanup (always with confirmation)."""
import shlex

from ..core import adb, safety
from ..ui import prompts
from ..utils.formatting import human_bytes, human_kb
from . import storage

TEMP_PATTERNS = ("*.tmp", "*.temp", "*.crdownload", "*.part", "*.partial")
MAX_SHOWN = 60


def cache_maintenance(session):
    prompts.title("Cache Maintenance")
    print("  This uses Android's built-in cache trimming (pm trim-caches).")
    print("  It only asks Android to free app CACHE. No user data is deleted.")
    before = storage.get_df(session, "/data")
    if before:
        print("  Free space now: %s" % human_kb(before["avail"]))
    if not prompts.confirm("Trim app caches now?"):
        prompts.info("Cancelled.")
        return
    r = adb.shell(session.serial, "pm trim-caches 999G", timeout=180)
    text = (r.out + r.err).strip()
    if not r.ok or "exception" in text.lower() or "denied" in text.lower():
        prompts.error("This device refused cache trimming.")
        if text:
            print("  " + text.splitlines()[0])
        print("  Alternative: Settings > Storage > Cached data (or per-app Clear cache).")
        return
    after = storage.get_df(session, "/data")
    prompts.ok("Cache trim requested.")
    if before and after:
        freed = after["avail"] - before["avail"]
        print("  Free space now: %s  (change: %s)" % (human_kb(after["avail"]),
              ("+" if freed >= 0 else "-") + human_kb(abs(freed))))


def _scan(session):
    names = " -o ".join("-name '%s'" % p for p in TEMP_PATTERNS)
    cmd_sd = ("find /sdcard -maxdepth 6 -path /sdcard/Android -prune -o -type f "
              "\\( %s \\) -print 2>/dev/null" % names)
    cmd_tmp = "find /data/local/tmp -maxdepth 2 -type f 2>/dev/null"
    paths = []
    for cmd in (cmd_sd, cmd_tmp):
        r = adb.shell(session.serial, cmd, timeout=180)
        for line in r.out.splitlines():
            line = line.strip()
            if line and safety.is_safe_temp_path(line) and line not in paths:
                paths.append(line)
    return paths


def _sizes(session, paths):
    sizes = {}
    for i in range(0, len(paths), 20):
        chunk = paths[i:i + 20]
        cmd = "stat -c '%%s|%%n' %s 2>/dev/null" % " ".join(shlex.quote(p) for p in chunk)
        r = adb.shell(session.serial, cmd)
        for line in r.out.splitlines():
            size, _, path = line.partition("|")
            if size.isdigit() and path:
                sizes[path] = int(size)
    return sizes


def parse_selection(text, n):
    text = text.strip().lower()
    if text == "all":
        return list(range(n))
    idx = set()
    for part in text.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            idx.update(range(int(a) - 1, int(b)))
        else:
            idx.add(int(part) - 1)
    if not idx or any(i < 0 or i >= n for i in idx):
        raise ValueError("out of range")
    return sorted(idx)


def temp_cleanup(session):
    prompts.title("Temporary File Cleanup")
    print("  Scanning for temp files (*.tmp, *.temp, *.crdownload, *.part, *.partial)")
    print("  and files in /data/local/tmp. Nothing is deleted without your approval.")
    paths = _scan(session)
    if not paths:
        prompts.ok("No temporary files found.")
        return
    sizes = _sizes(session, paths)
    shown = paths[:MAX_SHOWN]
    print("\n  Found %d file(s):" % len(paths))
    for i, p in enumerate(shown, 1):
        print("  %3d. %9s  %s" % (i, human_bytes(sizes[p]) if p in sizes else "?", p))
    if len(paths) > MAX_SHOWN:
        prompts.warn("Only the first %d are shown and selectable." % MAX_SHOWN)
    prompts.warn("Files in /data/local/tmp may have been put there on purpose. Review the list!")

    ans = prompts.ask("Numbers to delete (e.g. 1,3,5-8), 'all', or Enter to cancel: ")
    if not ans.strip():
        prompts.info("Nothing deleted.")
        return
    try:
        chosen = [shown[i] for i in parse_selection(ans, len(shown))]
    except ValueError:
        prompts.error("Invalid selection. Nothing deleted.")
        return

    total = sum(sizes.get(p, 0) for p in chosen)
    print("\n  About to PERMANENTLY delete %d file(s) (%s)." % (len(chosen), human_bytes(total)))
    if not prompts.confirm("This cannot be undone.", strict=True):
        prompts.info("Cancelled. Nothing deleted.")
        return

    deleted = failed = 0
    for p in chosen:
        try:
            r = adb.shell(session.serial, "rm -f -- " + shlex.quote(p))
        except safety.SafetyError as e:
            prompts.warn("Skipped %s (%s)" % (p, e))
            failed += 1
            continue
        if r.ok:
            deleted += 1
        else:
            failed += 1
            prompts.warn("Could not delete: %s" % p)
    prompts.ok("Deleted %d file(s), %d failed." % (deleted, failed))
