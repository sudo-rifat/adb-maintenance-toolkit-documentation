"""RAM information."""
from ..core import adb
from ..ui import prompts
from ..utils.formatting import bar, human_kb, percent


def _meminfo(text):
    data = {}
    for line in text.splitlines():
        parts = line.replace(":", " ").split()
        if len(parts) >= 2 and parts[1].isdigit():
            data[parts[0]] = int(parts[1])
    return data


def show_ram_info(session):
    prompts.title("RAM Information")
    r = adb.shell(session.serial, "cat /proc/meminfo")
    d = _meminfo(r.out)
    if "MemTotal" not in d:
        prompts.error("Could not read memory information.")
        return
    total = d["MemTotal"]
    avail = d.get("MemAvailable", d.get("MemFree", 0))
    used = total - avail
    rows = [
        ("Total RAM", human_kb(total)),
        ("Used", human_kb(used)),
        ("Available", human_kb(avail)),
        ("Usage", bar(percent(used, total))),
    ]
    if d.get("SwapTotal"):
        rows.append(("Swap (used/total)", "%s / %s" % (human_kb(d["SwapTotal"] - d.get("SwapFree", 0)), human_kb(d["SwapTotal"]))))
    prompts.table(rows)
