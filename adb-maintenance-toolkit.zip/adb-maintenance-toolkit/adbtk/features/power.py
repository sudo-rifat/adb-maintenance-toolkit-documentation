"""Device reboot (with confirmation)."""
from ..core import adb
from ..ui import prompts


def reboot_device(session):
    prompts.title("Device Reboot")
    print("  1) Normal reboot")
    print("  2) Reboot to recovery   (advanced)")
    print("  3) Reboot to bootloader (advanced)")
    print("  0) Cancel")
    choice = prompts.ask("Choice: ").strip()
    modes = {"1": [], "2": ["recovery"], "3": ["bootloader"]}
    if choice not in modes:
        prompts.info("Cancelled.")
        return
    name = {"1": "normal reboot", "2": "recovery", "3": "bootloader"}[choice]
    if not prompts.confirm("Reboot the device now (%s)? Unsaved work on the phone will be lost." % name,
                           strict=True):
        prompts.info("Cancelled.")
        return
    r = adb.run(["reboot"] + modes[choice], serial=session.serial, timeout=30)
    if r.ok:
        prompts.ok("Reboot command sent. Wait until the phone is back, then pick a menu item again.")
    else:
        prompts.error("Reboot failed: %s" % (r.err.strip() or r.out.strip()))
