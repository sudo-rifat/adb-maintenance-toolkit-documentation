"""Storage analysis, usage and folder sizes (read-only)."""
from ..core import adb
from ..ui import prompts
from ..utils.formatting import bar, human_kb, percent

WANTED_MOUNTS = ("/", "/system", "/vendor", "/product", "/data", "/cache", "/storage/emulated")


def parse_df(text):
    """Parse `df -k` output into a list of dicts."""
    rows = []
    for line in text.splitlines()[1:]:
        f = line.split()
        if len(f) < 6:
            continue
        try:
            rows.append({"fs": f[0], "total": int(f[-5]), "used": int(f[-4]),
                         "avail": int(f[-3]), "pct": f[-2], "mount": f[-1]})
        except ValueError:
            continue
    return rows


def get_df(session, path):
    """Return dict for one path, or None."""
    r = adb.shell(session.serial, "df -k %s" % path)
    rows = parse_df(r.out)
    return rows[-1] if rows else None


def storage_analysis(session):
    prompts.title("Storage Analysis")
    r = adb.shell(session.serial, "df -k")
    rows = [x for x in parse_df(r.out)
            if x["mount"] in WANTED_MOUNTS or x["mount"].startswith("/storage/")]
    if not rows:
        prompts.error("Could not read partition information.")
        return
    print("  %-22s %10s %10s %10s %6s" % ("Mount", "Total", "Used", "Free", "Use%"))
    seen = set()
    for x in rows:
        key = (x["total"], x["used"], x["mount"])
        if key in seen:
            continue
        seen.add(key)
        print("  %-22s %10s %10s %10s %6s" % (x["mount"], human_kb(x["total"]),
              human_kb(x["used"]), human_kb(x["avail"]), x["pct"]))

    print("\n  Largest folders in internal storage (/sdcard):")
    r = adb.shell(session.serial, "du -sk /sdcard/* 2>/dev/null", timeout=180)
    items = []
    for line in r.out.splitlines():
        parts = line.split(None, 1)
        if len(parts) == 2 and parts[0].isdigit():
            items.append((int(parts[0]), parts[1].strip()))
    if not items:
        prompts.warn("Folder sizes are not available.")
        return
    for size, path in sorted(items, reverse=True)[:10]:
        print("   %10s  %s" % (human_kb(size), path))


def storage_usage(session):
    prompts.title("Storage Usage")
    for label, path in (("App data (/data)", "/data"), ("Shared storage (/sdcard)", "/sdcard")):
        d = get_df(session, path)
        if not d:
            prompts.warn("%s: not available" % label)
            continue
        print("  %s" % label)
        print("    %s" % bar(percent(d["used"], d["total"])))
        print("    Used %s of %s  |  Free %s" % (human_kb(d["used"]), human_kb(d["total"]), human_kb(d["avail"])))


def internal_storage(session):
    prompts.title("Internal Storage")
    d = get_df(session, "/sdcard")
    if not d:
        prompts.error("Could not read internal storage.")
        return
    prompts.table([
        ("Total", human_kb(d["total"])),
        ("Used", human_kb(d["used"])),
        ("Free", human_kb(d["avail"])),
        ("Usage", bar(percent(d["used"], d["total"]))),
    ])


def folder_usage(session, folder):
    path = "/sdcard/%s" % folder
    prompts.title("%s Folder Usage" % folder)
    r = adb.shell(session.serial, "test -d %s && echo yes || echo no" % path)
    if r.out.strip() != "yes":
        prompts.warn("%s does not exist on this device." % path)
        return
    r = adb.shell(session.serial, "du -sk %s 2>/dev/null" % path, timeout=180)
    parts = r.out.split()
    if not parts or not parts[0].isdigit():
        prompts.error("Could not measure the folder (permission denied?).")
        return
    size = int(parts[0])
    rows = [("Path", path), ("Size", human_kb(size))]
    r = adb.shell(session.serial, "find %s -type f 2>/dev/null | wc -l" % path, timeout=180)
    if r.out.strip().isdigit():
        rows.append(("Files", r.out.strip()))
    d = get_df(session, "/sdcard")
    if d and d["total"]:
        rows.append(("Share of storage", "%.1f%%" % percent(size, d["total"])))
    prompts.table(rows)
