"""Main interactive menu."""
from ..core import adb, device, safety
from ..features import apps, battery, device_info, maintenance, memory, power, storage
from . import prompts


def _folder(name):
    return lambda s: storage.folder_usage(s, name)


# number: (label, handler, needs_device)
ITEMS = {
    1: ("Device Connection", device.connection_menu, False),
    2: ("Storage Analysis", storage.storage_analysis, True),
    3: ("Storage Usage", storage.storage_usage, True),
    4: ("Battery Information", battery.show_battery_info, True),
    5: ("Battery Statistics", battery.show_battery_stats, True),
    6: ("RAM Information", memory.show_ram_info, True),
    7: ("Installed Apps", apps.show_installed, True),
    8: ("Third-party Apps", apps.show_third_party, True),
    9: ("System Apps", apps.show_system, True),
    10: ("Android Version", device_info.show_android_version, True),
    11: ("Device Model", device_info.show_model, True),
    12: ("Manufacturer", device_info.show_manufacturer, True),
    13: ("Internal Storage", storage.internal_storage, True),
    14: ("Download Folder Usage", _folder("Download"), True),
    15: ("DCIM Folder Usage", _folder("DCIM"), True),
    16: ("Pictures Folder Usage", _folder("Pictures"), True),
    17: ("Movies Folder Usage", _folder("Movies"), True),
    18: ("Music Folder Usage", _folder("Music"), True),
    19: ("Cache Maintenance", maintenance.cache_maintenance, True),
    20: ("Temporary File Cleanup", maintenance.temp_cleanup, True),
    21: ("Device Reboot", power.reboot_device, True),
    22: ("Exit", None, False),
}

HEADINGS = {1: "Connection", 2: "Storage", 4: "Battery", 6: "Memory", 7: "Apps",
            10: "Device Info", 13: "Storage Folders", 19: "Maintenance", 21: "Power"}


def show_menu(session):
    print("\n" + prompts.c("=" * 46, "36"))
    print(prompts.c("   ADB Maintenance Toolkit", "1;36"))
    print("   Device: %s" % session.label())
    print(prompts.c("=" * 46, "36"))
    for num, (label, _, _) in ITEMS.items():
        if num in HEADINGS:
            print(prompts.c("  -- %s --" % HEADINGS[num], "33"))
        print("   %2d) %s" % (num, label))


def run(session):
    print("ADB: %s  [%s]" % (adb.find_adb(), adb.adb_version()))
    try:
        device.select_device(session)
    except adb.AdbError as e:
        prompts.error(str(e))

    while True:
        show_menu(session)
        choice = prompts.ask("\nSelect an option (1-22): ").strip()
        if not choice.isdigit() or int(choice) not in ITEMS:
            prompts.warn("Please enter a number from 1 to 22.")
            continue
        num = int(choice)
        label, handler, needs_device = ITEMS[num]
        if num == 22:
            print("Goodbye!")
            return
        try:
            if needs_device and not device.ensure_connected(session):
                prompts.pause()
                continue
            handler(session)
        except safety.SafetyError as e:
            prompts.error("Blocked by safety rules: %s" % e)
        except adb.AdbError as e:
            prompts.error(str(e))
        prompts.pause()
