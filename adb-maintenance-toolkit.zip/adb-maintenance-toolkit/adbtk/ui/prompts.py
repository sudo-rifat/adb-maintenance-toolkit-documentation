"""Terminal colors, prompts and confirmation helpers."""
import os
import sys

USE_COLOR = (
    sys.stdout.isatty()
    and not os.environ.get("NO_COLOR")
    and (os.name != "nt" or bool(os.environ.get("WT_SESSION")))
)


def c(text, code):
    return "\033[%sm%s\033[0m" % (code, text) if USE_COLOR else text


def title(text):
    print("\n" + c("=== %s ===" % text, "1;36"))


def info(text):
    print(c(text, "0"))


def ok(text):
    print(c("[OK] " + text, "32"))


def warn(text):
    print(c("[!] " + text, "33"))


def error(text):
    print(c("[X] " + text, "31"))


def table(rows):
    if not rows:
        return
    width = max(len(k) for k, _ in rows)
    for k, v in rows:
        print("  %s : %s" % (k.ljust(width), v))


def ask(prompt):
    return input(prompt)


def pause():
    ask(c("\nPress Enter to continue...", "2"))


def confirm(message, default=False, strict=False):
    """strict=True requires typing the word 'yes' (for risky actions)."""
    if strict:
        return ask("%s Type 'yes' to continue: " % c(message, "1;33")).strip().lower() == "yes"
    hint = "[Y/n]" if default else "[y/N]"
    ans = ask("%s %s: " % (message, hint)).strip().lower()
    if not ans:
        return default
    return ans in ("y", "yes")
