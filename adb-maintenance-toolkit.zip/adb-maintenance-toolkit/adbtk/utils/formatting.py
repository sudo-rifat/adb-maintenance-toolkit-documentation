"""Small helpers for formatting sizes, percentages and serial numbers."""


def human_kb(kb):
    """Convert a number of kilobytes into a readable string."""
    try:
        size = float(kb)
    except (TypeError, ValueError):
        return "N/A"
    units = ["KB", "MB", "GB", "TB"]
    i = 0
    while size >= 1024 and i < len(units) - 1:
        size /= 1024
        i += 1
    if i == 0:
        return "%d KB" % int(size)
    return "%.1f %s" % (size, units[i])


def human_bytes(b):
    try:
        return human_kb(float(b) / 1024)
    except (TypeError, ValueError):
        return "N/A"


def mask_serial(serial):
    """Hide the middle of a serial number: ABCDEF123456 -> AB********56"""
    if not serial:
        return "N/A"
    if len(serial) <= 4:
        return "*" * len(serial)
    return serial[:2] + "*" * (len(serial) - 4) + serial[-2:]


def percent(used, total):
    try:
        return 100.0 * float(used) / float(total) if float(total) > 0 else 0.0
    except (TypeError, ValueError):
        return 0.0


def bar(pct, width=30):
    pct = max(0.0, min(100.0, pct))
    filled = int(round(width * pct / 100.0))
    return "[" + "#" * filled + "-" * (width - filled) + "] %.0f%%" % pct
