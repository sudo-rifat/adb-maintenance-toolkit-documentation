"""Detect the platform (Linux / Termux / Windows / macOS) and give ADB help."""
import os
import sys


def detect_platform():
    if os.environ.get("TERMUX_VERSION") or "com.termux" in os.environ.get("PREFIX", ""):
        return "termux"
    if sys.platform.startswith("win"):
        return "windows"
    if sys.platform == "darwin":
        return "macos"
    if sys.platform.startswith("linux"):
        return "linux"
    return "unknown"


def common_adb_paths():
    """Extra places to look for adb if it is not on PATH."""
    home = os.path.expanduser("~")
    paths = [
        "/usr/bin/adb",
        "/usr/local/bin/adb",
        "/data/data/com.termux/files/usr/bin/adb",
        os.path.join(home, "platform-tools", "adb"),
        os.path.join(home, "Android", "Sdk", "platform-tools", "adb"),
    ]
    if detect_platform() == "windows":
        paths += [
            os.path.join(home, "platform-tools", "adb.exe"),
            r"C:\platform-tools\adb.exe",
        ]
    return paths


def adb_install_help():
    plat = detect_platform()
    if plat == "termux":
        return (
            "Termux detected. Install ADB with:\n"
            "    pkg install android-tools\n\n"
            "To control the SAME phone from Termux (Android 11+):\n"
            "  1. Settings > Developer options > Wireless debugging > ON\n"
            "  2. Use 'Pair device with pairing code' (menu 1 > Pair in this tool)\n"
            "  3. Then connect using the IP:PORT shown on the Wireless debugging screen."
        )
    if plat == "linux":
        return (
            "Linux detected. On Ubuntu / Debian install ADB with:\n"
            "    sudo apt update && sudo apt install adb\n\n"
            "Or download Google's 'SDK Platform-Tools' and add the folder to PATH:\n"
            "    https://developer.android.com/tools/releases/platform-tools"
        )
    if plat == "macos":
        return "macOS detected. Install ADB with:\n    brew install android-platform-tools"
    if plat == "windows":
        return (
            "Windows detected. Download 'SDK Platform-Tools' from:\n"
            "    https://developer.android.com/tools/releases/platform-tools\n"
            "Extract it (e.g. C:\\platform-tools) and add that folder to PATH."
        )
    return "Install Android SDK Platform-Tools: https://developer.android.com/tools/releases/platform-tools"
