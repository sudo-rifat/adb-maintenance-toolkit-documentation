#!/usr/bin/env python3
"""A FAKE adb for trying the toolkit without a phone.

    chmod +x tests/fake_adb.py
    ADBTK_ADB=$PWD/tests/fake_adb.py python3 -m adbtk
"""
import sys

args = sys.argv[1:]
if args[:1] == ["-s"]:
    args = args[2:]
cmd = args[0] if args else ""

PROPS = {"ro.build.version.release": "14", "ro.build.version.sdk": "34",
         "ro.build.version.security_patch": "2024-05-05", "ro.build.id": "UP1A.231005",
         "ro.product.model": "Pixel 7", "ro.product.device": "panther",
         "ro.product.name": "panther", "ro.product.manufacturer": "Google",
         "ro.product.brand": "google", "ro.hardware": "tensor"}

BATTERY = """Current Battery Service state:
  AC powered: false
  USB powered: true
  Wireless powered: false
  status: 2
  health: 2
  present: true
  level: 85
  scale: 100
  voltage: 4123
  temperature: 301
  technology: Li-ion
"""
DF = """Filesystem 1K-blocks Used Available Use% Mounted on
/dev/block/dm-1 6000000 4000000 2000000 67% /
/dev/block/dm-5 110000000 60000000 50000000 55% /data
/dev/fuse 110000000 60000000 50000000 55% /storage/emulated
"""

if cmd == "version":
    print("Android Debug Bridge version 1.0.41 (fake)")
elif cmd == "devices":
    print("List of devices attached\nEMU1234567890 device usb:1-1 product:panther model:Pixel_7 device:panther transport_id:1\n")
elif cmd == "get-state":
    print("device")
elif cmd == "reboot":
    pass
elif cmd == "shell":
    s = " ".join(args[1:])
    if s.startswith("getprop "):
        print(PROPS.get(s.split()[1], ""))
    elif s == "dumpsys battery":
        print(BATTERY)
    elif s == "dumpsys batterystats":
        print("  Time on battery: 3h 2m 1s\n  Estimated battery capacity: 4355 mAh\n  Computed drain: 812")
    elif s == "cat /proc/meminfo":
        print("MemTotal: 7900000 kB\nMemFree: 500000 kB\nMemAvailable: 3000000 kB\nSwapTotal: 2000000 kB\nSwapFree: 1500000 kB")
    elif s == "df -k":
        print(DF)
    elif s.startswith("df -k "):
        print(DF.splitlines()[0]); print(DF.splitlines()[2] if "/data" in s else DF.splitlines()[3])
    elif s.startswith("du -sk /sdcard/*"):
        print("2048000\t/sdcard/DCIM\n512000\t/sdcard/Download\n1024\t/sdcard/Music")
    elif s.startswith("du -sk"):
        print("512000\t" + s.split()[2])
    elif s.startswith("test -d"):
        print("no" if "Movies" in s else "yes")
    elif "| wc -l" in s:
        print("42")
    elif s.startswith("pm list packages"):
        for p in ("com.android.settings", "com.whatsapp", "org.example.app"):
            if "-3" in s and p.startswith("com.android"):
                continue
            print("package:" + p)
    elif s.startswith("pm trim-caches"):
        pass
    elif s.startswith("find /sdcard"):
        print("/sdcard/Download/video.part\n/sdcard/cache1.tmp")
    elif s.startswith("find /data/local/tmp"):
        print("/data/local/tmp/old.bin")
    elif s.startswith("stat -c"):
        print("1048576|/sdcard/Download/video.part\n2048|/sdcard/cache1.tmp\n100|/data/local/tmp/old.bin")
    elif s.startswith("rm -f -- "):
        pass
    else:
        sys.stderr.write("fake adb: unknown command: " + s + "\n")
        sys.exit(1)
elif cmd in ("connect", "pair"):
    print("connected (fake)")
