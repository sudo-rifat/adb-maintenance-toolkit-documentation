import unittest

from adbtk.features.maintenance import parse_selection
from adbtk.features.storage import parse_df
from adbtk.utils.formatting import human_kb, mask_serial


class FormattingTests(unittest.TestCase):
    def test_human_kb(self):
        self.assertEqual(human_kb(512), "512 KB")
        self.assertEqual(human_kb(2048), "2.0 MB")
        self.assertEqual(human_kb("x"), "N/A")

    def test_mask_serial(self):
        self.assertEqual(mask_serial("ABCDEF123456"), "AB********56")
        self.assertEqual(mask_serial(""), "N/A")

    def test_parse_selection(self):
        self.assertEqual(parse_selection("1,3-4", 5), [0, 2, 3])
        self.assertEqual(parse_selection("all", 3), [0, 1, 2])
        with self.assertRaises(ValueError):
            parse_selection("9", 3)

    def test_parse_df(self):
        text = "Filesystem 1K-blocks Used Available Use% Mounted on\n/dev/x 1000 400 600 40% /data\n"
        self.assertEqual(parse_df(text)[0]["mount"], "/data")


if __name__ == "__main__":
    unittest.main()
