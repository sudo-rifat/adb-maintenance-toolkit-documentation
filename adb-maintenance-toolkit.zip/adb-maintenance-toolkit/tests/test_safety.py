import unittest

from adbtk.core import safety


class SafetyTests(unittest.TestCase):
    def blocked(self, cmd):
        with self.assertRaises(safety.SafetyError):
            safety.check_shell_command(cmd)

    def test_dangerous_commands_blocked(self):
        for cmd in ["rm -rf /", "rm -rf /data/*", "rm -rf /*", "rm -r /sdcard",
                    "pm clear --all", "pm clear com.app", "pm uninstall com.app",
                    "dd if=/dev/zero of=/dev/block/sda", "mkfs.ext4 /dev/x", "su -c id",
                    "rm -f -- /sdcard/a.tmp; rm -rf /", "rm -f -- /data/system/x"]:
            self.blocked(cmd)

    def test_safe_commands_allowed(self):
        for cmd in ["getprop ro.product.model", "dumpsys battery", "df -k",
                    "pm list packages -3", "pm trim-caches 999G", "du -sk /sdcard/* 2>/dev/null"]:
            safety.check_shell_command(cmd)

    def test_single_safe_delete_allowed(self):
        safety.check_shell_command("rm -f -- /sdcard/Download/a.tmp")
        safety.check_shell_command("rm -f -- '/sdcard/My Files/a b.tmp'")

    def test_unsafe_delete_paths_blocked(self):
        for p in ["/sdcard/Android/data/x.tmp", "/sdcard/../data/x", "/system/x", "/sdcard/", "/sdcard/*.tmp"]:
            self.assertFalse(safety.is_safe_temp_path(p))


if __name__ == "__main__":
    unittest.main()
